void printEvents(){
	cout<<"Below are the Event Details."<<endl;
	cout<<"1. live music"<<endl;
	cout<<"2. stand-up comedy"<<endl;
	cout<<"3. film"<<endl;
}
void live_music_detail(){
	cout<<"Availability Type: standing only"<<endl;
	cout<<"Venue Capacity: 300"<<endl;
}
void stand_up_comedy_detail(){
	cout<<"Availability Type: seated"<<endl;
	cout<<"Venue Capacity:  200"<<endl;
}
void film_detail(){
	cout<<"Availability Type: seated"<<endl;
	cout<<"Venue Capacity:  available only in 2D and 3D"<<endl;
}
