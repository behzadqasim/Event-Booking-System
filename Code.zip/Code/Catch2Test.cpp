#include <string>
#include <iostream>
#include "AddCancelEvent.h"
using namespace std;

class CatchTest {      
  public:           
    string personName="TestName";
    string eventName="TestEvent";
    Catch2Test(){
    	Event e1;
    	e1.eventName = eventName;
    	e1.personName = personName;
	}
	  
};

int main()
{
	CatchTest obj;
	cout<<"Test Performed Successfully.";
	return 0;
}
