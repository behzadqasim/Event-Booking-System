#include <fstream>
#include <string>
#include <iostream>
#include "AddCancelEvent.h"
#include "EventDetails.h"
using namespace std;
void addbookingevent()
{
  
  std::ofstream outfile;
  outfile.open("registeredlist.txt", std::ios_base::app); // append instead of overwrite
  outfile << addeventtofile()+"\n"; 
  cout<<"Event Added/Booked Successfully.";
}
void loadDatafromFile(){
  string line;
  ifstream myfile ("registeredlist.txt");
  if (myfile.is_open())
  {
    while ( getline (myfile,line) )
    {
      cout << line << '\n';
    }
    myfile.close();
  }
  else cout << "Unable to open file"; 
}
int main()
{
	bool condition = true;
	while(condition){
	int userchoice;
	cout<<"Press 1. add a booking for an event."<<endl;
    cout<<"Press 2. cancel/refund a booking."<<endl;
    cout<<"Press 3. list all events."<<endl;
    cout<<"Press 4. list details and availability of a given event"<<endl;
    cout<<"Press 5. load data from a file."<<endl;
    cout<<"Press 6. save data to file."<<endl;
    cout<<"Press 0. to Quit."<<endl;
    cout<<"--> ";
    cin>>userchoice;
    if(userchoice==1){
    	printEvents();
    	addbookingevent();
	}
	else if(userchoice==2){
		cancelEvent();
	}
	else if(userchoice==0){
		condition=false;
	}
	else if(userchoice==3){
		printEvents();
	}
	else if(userchoice==4){
		printEvents();
		int selectedEvent;
		cout<<"Select any above event by number (1-3) to check details: ";
		cin>>selectedEvent;
		if(selectedEvent==1){
			live_music_detail();
		}
		else if(selectedEvent==2){
			stand_up_comedy_detail();
		}
		else if(selectedEvent==3){
			film_detail();
		}
		else{
			cout<<"You Select an invalid event."<<endl;
		}
	}
	else if(userchoice==5){
		loadDatafromFile();
	}
	else if(userchoice==6){
		cout<<"Data is saved in 'registeredlist.txt' file"<<endl;
	}
	else{
		cout<<"You Entered an incorrect option.";
	}
      cout<<"\n";
	}
    
    
    return 0;
}
