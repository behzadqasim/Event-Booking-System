#include <iostream>
#include <string>
using namespace std;
struct Event
{
    string personName;
    string eventName;
};
string addeventtofile(){
	Event e1;
	string result;
	cout << "Enter Booking name: ";
    cin>>e1.personName;
	int selectEvent;
    cout << "Enter Booking Event from above List(1-3): ";
    cin>>selectEvent;
    if(selectEvent==1){
    cout<<"You Select Live Music."<<endl;
    e1.eventName="Live Music";
    result = e1.personName + "," + e1.eventName;
	}
	else if(selectEvent==2){
		cout<<"You Select Standup Comedy."<<endl;
		string seatNumber;
		cout<<"Enter Seat Number(1-200): ";
		cin>>seatNumber;
			e1.eventName="Standup Comedy";
			result = e1.personName + "," + e1.eventName +"," +seatNumber;
		
	}
	else if(selectEvent==3){
		cout<<"You Select Film."<<endl;
		string type;
		cout<<"Enter booking Type (2D or 3D): ";
		cin>>type;
		if(type!=""){
			e1.eventName="Film";
			result = e1.personName + "," + e1.eventName +"," + type;
		}
		else{
			cout<<"You entered an incorrect type."<<endl;
		}
	}
    
    return result;
}
void cancelEvent(){
	Event e1;
    cout << "Enter name: ";
    cin>>e1.personName;
    cout << "Enter Event name: ";
    cin>>e1.eventName;
    cout << "Event Cancel Successfully."<<endl;
}

